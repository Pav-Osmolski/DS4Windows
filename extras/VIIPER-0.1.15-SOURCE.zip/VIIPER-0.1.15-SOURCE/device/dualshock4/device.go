package dualshock4

import (
	"context"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"sync"
	"sync/atomic"
	"time"

	"github.com/Alia5/VIIPER/device"
	"github.com/Alia5/VIIPER/device/internal/microphonebuffer"
	"github.com/Alia5/VIIPER/usb"
	"github.com/Alia5/VIIPER/usbip"
)

const (
	microphoneTargetClientFrames  = 6  // 60 ms absorbs the DS4's 8/8/8/16 ms framing and host scheduling jitter.
	microphoneMaximumClientFrames = 20 // 200 ms emergency ceiling for full-duplex BT bursts; steady state remains about 55 ms.
)

type DualShock4 struct {
	inputCh        chan *InputState
	inputState     *InputState
	inputPublishMu sync.Mutex
	metaState      *MetaState

	outputFunc               func(OutputState)
	speakerFunc              func([]byte)
	speakerResetFunc         func()
	outputState              OutputState
	outputSeen               bool
	descriptor               usb.Descriptor
	transportOutputFunc      func(OutputState) bool
	outputCallbackGeneration uint64
	nextOutputGeneration     uint64

	probeSelector       [3]byte
	telemetrySubcommand byte

	usbPacketCounter uint32
	timestampBase    time.Time

	speakerInterfaceActive    bool
	microphoneInterfaceActive bool
	microphoneInput           bool
	speakerOutput             bool
	streamFrameVersion        byte
	microphoneBuffer          microphonebuffer.Buffer
	microphoneSignal          chan struct{}

	mtx sync.Mutex
}

func New(o *device.CreateOptions) (*DualShock4, error) {
	metaState := &MetaState{
		SerialNumber:       DefaultSerialString,
		Board:              DefaultBoardString,
		BuildTime:          DefaultBuildTime,
		BatteryStatus:      DefaultBatteryStatus,
		TemperatureCelsius: DefaultTemperature,
		BatteryVoltage:     DefaultVoltage,
	}
	if o != nil && o.DeviceSpecific != "" {
		var newMeta MetaState
		err := json.Unmarshal([]byte(o.DeviceSpecific), &newMeta)
		if err != nil {
			return nil, fmt.Errorf("invalid JSON payload: %w", err)
		}
		if newMeta.SerialNumber != "" {
			metaState.SerialNumber = newMeta.SerialNumber
		}
		if newMeta.Board != "" {
			metaState.Board = newMeta.Board
		}
		if !newMeta.BuildTime.IsZero() {
			metaState.BuildTime = newMeta.BuildTime
		}
		if newMeta.BatteryStatus != 0 {
			metaState.BatteryStatus = newMeta.BatteryStatus
		}
		if newMeta.TemperatureCelsius != 0 {
			metaState.TemperatureCelsius = newMeta.TemperatureCelsius
		}
		if newMeta.BatteryVoltage != 0 {
			metaState.BatteryVoltage = newMeta.BatteryVoltage
		}
	}

	d := &DualShock4{
		descriptor: defaultDescriptor,
		metaState:  metaState,
		microphoneBuffer: microphonebuffer.New(
			USBMicrophonePacketSize,
			USBMicrophoneChannels*USBMicrophoneBytesPerSample,
			USBMicrophoneClientFrameSize,
			microphoneTargetClientFrames,
			microphoneMaximumClientFrames,
		),
		microphoneSignal: make(chan struct{}, 1),
	}
	if o != nil {
		if o.IDVendor != nil {
			d.descriptor.Device.IDVendor = *o.IDVendor
		}
		if o.IDProduct != nil {
			d.descriptor.Device.IDProduct = *o.IDProduct
		}
		if len(d.metaState.SerialNumber) > 0 && len(d.metaState.SerialNumber) <= 16 {
			d.metaState.SerialNumber = fmt.Sprintf("%016s", d.metaState.SerialNumber)
		}
	}

	slog.Info("DS4 device instantiated",
		"vid", d.descriptor.Device.IDVendor,
		"pid", d.descriptor.Device.IDProduct,
		"interfaces", len(d.descriptor.Interfaces))

	d.inputState = NewInputState()
	d.inputCh = make(chan *InputState, 1)
	d.inputCh <- d.inputState
	d.timestampBase = time.Now()

	return d, nil
}

func (d *DualShock4) SetMetaState(meta MetaState) {
	d.mtx.Lock()
	defer d.mtx.Unlock()
	d.metaState = &meta
}

func (d *DualShock4) SetOutputCallback(f func(OutputState)) {
	var latest OutputState
	var replay bool

	d.mtx.Lock()
	d.outputFunc = f
	if f != nil && d.outputSeen {
		latest = d.outputState
		replay = true
	}
	d.mtx.Unlock()

	if replay {
		f(latest)
	}
}

// The framed sink performs bounded admission only, never socket I/O. Register
// its output/audio/reset callbacks together; stale cleanup cannot clear a new
// transport. The original public legacy callback remains unchanged.
func (d *DualShock4) setFramedOutputCallbacks(output func(OutputState) bool,
	speaker func([]byte), reset func()) (uint64, bool) {
	d.mtx.Lock()
	defer d.mtx.Unlock()
	if output == nil || d.transportOutputFunc != nil || d.nextOutputGeneration == ^uint64(0) {
		return 0, false
	}
	if d.outputSeen && !output(d.outputState) {
		return 0, false
	}
	d.nextOutputGeneration++
	d.outputCallbackGeneration = d.nextOutputGeneration
	d.transportOutputFunc = output
	d.speakerFunc = speaker
	d.speakerResetFunc = reset
	return d.outputCallbackGeneration, true
}

func (d *DualShock4) clearFramedOutputCallbacks(generation uint64) bool {
	d.mtx.Lock()
	defer d.mtx.Unlock()
	if generation == 0 || generation != d.outputCallbackGeneration {
		return false
	}
	d.transportOutputFunc = nil
	d.speakerFunc = nil
	d.speakerResetFunc = nil
	d.outputCallbackGeneration = 0
	return true
}

// TryHandleOutputCommand uses the existing USB/IP admission contract: a full
// distinct-command queue is ENOSPC with zero actual length, not false success.
// Host retry is not guaranteed. Legacy/nonframed modes retain their old route.
func (d *DualShock4) TryHandleOutputCommand(endpoint uint8,
	setup [8]byte, data []byte) (handled, accepted bool) {
	if endpoint == EndpointOut&0x0f {
		return d.tryAdmitFramedOutput(data)
	}
	if endpoint != 0 || setup[0] != hidClassOUT || setup[1] != hidSetReport ||
		binary.LittleEndian.Uint16(setup[2:4]) != uint16(reportTypeOutput)<<8|uint16(ReportIDOutput) {
		return false, false
	}
	interfaceNumber := binary.LittleEndian.Uint16(setup[4:6])
	if interfaceNumber > 0xff || int(binary.LittleEndian.Uint16(setup[6:8])) != len(data) {
		return false, false
	}
	iface, exists := d.descriptor.Interface(uint8(interfaceNumber))
	if !exists || iface.Descriptor.BInterfaceClass != 0x03 {
		return false, false
	}
	return d.tryAdmitFramedOutput(data)
}

func (d *DualShock4) tryAdmitFramedOutput(data []byte) (handled, accepted bool) {
	d.mtx.Lock()
	defer d.mtx.Unlock()
	if d.transportOutputFunc == nil {
		return false, false
	}
	if len(data) < 11 || data[0] != ReportIDOutput {
		return true, false
	}
	feedback := mergeOutputReport(d.outputState, data)
	if !d.transportOutputFunc(feedback) {
		return true, false
	}
	d.outputState = feedback
	d.outputSeen = true
	return true, true
}

func (d *DualShock4) SetSpeakerCallback(f func([]byte)) {
	d.mtx.Lock()
	d.speakerFunc = f
	d.mtx.Unlock()
}

// SetSpeakerResetCallback installs the transport-side queue reset paired with
// SetSpeakerCallback. Interface transitions and endpoint pipe resets must drop
// speaker PCM from the previous USB presentation generation.
func (d *DualShock4) SetSpeakerResetCallback(f func()) {
	d.mtx.Lock()
	d.speakerResetFunc = f
	d.mtx.Unlock()
}

func (d *DualShock4) UpdateInputState(state *InputState) {
	d.inputPublishMu.Lock()
	defer d.inputPublishMu.Unlock()

	next := *NewInputState()
	if state != nil {
		next = *state
	}
	nextPtr := &next

	d.mtx.Lock()
	d.inputState = nextPtr
	d.mtx.Unlock()
	select {
	case <-d.inputCh:
	default:
	}
	d.inputCh <- nextPtr
}

func (d *DualShock4) GetDescriptor() *usb.Descriptor {
	return &d.descriptor
}

func (d *DualShock4) GetDeviceSpecificArgs() map[string]any {
	var res map[string]any
	d.mtx.Lock()
	defer d.mtx.Unlock()

	bytes, err := json.Marshal(d.metaState)
	if err != nil {
		return map[string]any{}
	}
	err = json.Unmarshal(bytes, &res)
	if err != nil {
		return map[string]any{}
	}
	res["speakerInterfaceActive"] = d.speakerInterfaceActive
	res["microphoneInterfaceActive"] = d.microphoneInterfaceActive
	microphoneState := d.microphoneBuffer.State()
	res["queuedMicrophoneBytes"] = microphoneState.QueuedBytes
	res["microphoneQueueTargetBytes"] = microphoneState.TargetBytes
	res["microphoneQueueMaximumBytes"] = microphoneState.MaximumBytes
	res["microphoneFilteredQueueBytes"] = microphoneState.FilteredBytes
	res["microphoneQueuePrimed"] = microphoneState.Primed
	res["microphoneUnderruns"] = microphoneState.Underruns
	res["microphoneReprimes"] = microphoneState.Reprimes
	res["microphoneDroppedBytes"] = microphoneState.DroppedBytes
	res["microphonePacketsRead"] = microphoneState.PacketsRead
	res["microphoneZeroPackets"] = microphoneState.ZeroPackets
	res["microphoneOverflowEvents"] = microphoneState.OverflowEvents
	res["microphoneShortPackets"] = microphoneState.ShortPackets
	res["microphoneLongPackets"] = microphoneState.LongPackets
	res["microphoneServoRatePPM"] = microphoneState.ServoRatePPM
	res["microphoneLowWaterBytes"] = microphoneState.LowWaterBytes
	res["microphoneHighWaterBytes"] = microphoneState.HighWaterBytes
	res["microphoneQueueFrames"] = microphoneState.QueueFrames
	res["microphoneQueueFastGaps"] = microphoneState.QueueFastGaps
	res["microphoneQueueLateGaps"] = microphoneState.QueueLateGaps
	res["microphoneQueueMinGapUS"] = microphoneState.QueueMinGapUS
	res["microphoneQueueMaxGapUS"] = microphoneState.QueueMaxGapUS
	res["microphoneReadFastGaps"] = microphoneState.ReadFastGaps
	res["microphoneReadLateGaps"] = microphoneState.ReadLateGaps
	res["microphoneReadMinGapUS"] = microphoneState.ReadMinGapUS
	res["microphoneReadMaxGapUS"] = microphoneState.ReadMaxGapUS
	return res
}

func (d *DualShock4) SetInterfaceAltSetting(iface, alt uint8) {
	d.mtx.Lock()
	var resetSpeaker func()
	switch iface {
	case InterfaceSpeaker:
		wasActive := d.speakerInterfaceActive
		d.speakerInterfaceActive = alt != 0
		if wasActive != d.speakerInterfaceActive {
			resetSpeaker = d.speakerResetFunc
		}
	case InterfaceMicrophone:
		wasActive := d.microphoneInterfaceActive
		d.microphoneInterfaceActive = alt != 0
		if wasActive != d.microphoneInterfaceActive {
			d.microphoneBuffer.Reset()
			d.drainMicrophoneSignal()
		}
	}
	d.mtx.Unlock()

	// The transport reset may wait for an in-flight socket write. Never hold the
	// device mutex across that wait: output and USB teardown callbacks also need
	// to acquire it before the writer can finish shutting down.
	if resetSpeaker != nil {
		resetSpeaker()
	}
}

// ResetEndpoint implements usb.EndpointResetDevice. CLEAR_FEATURE(HALT)
// preserves the selected alternate setting while establishing a hard data
// generation boundary for the affected audio pipe.
func (d *DualShock4) ResetEndpoint(endpoint uint8) {
	d.mtx.Lock()
	var resetSpeaker func()
	switch endpoint {
	case EndpointAudioOut:
		resetSpeaker = d.speakerResetFunc
	case EndpointMicrophoneIn:
		d.microphoneBuffer.Reset()
		d.drainMicrophoneSignal()
	}
	d.mtx.Unlock()

	if resetSpeaker != nil {
		resetSpeaker()
	}
}

func (d *DualShock4) HandleTransfer(ctx context.Context, ep uint32, dir uint32, out []byte) []byte {
	epNumber := ep & 0x0F
	if dir == usbip.DirIn {
		switch epNumber {
		case 4:
			select {
			case <-ctx.Done():
				if errors.Is(ctx.Err(), context.DeadlineExceeded) {
					d.mtx.Lock()
					is := d.inputState
					ms := *d.metaState
					d.mtx.Unlock()
					return d.buildUSBInputReport(is, &ms)
				}
				return nil
			case is := <-d.inputCh:
				d.mtx.Lock()
				ms := *d.metaState
				d.mtx.Unlock()
				return d.buildUSBInputReport(is, &ms)
			}
		case EndpointMicrophoneIn & 0x0F:
			return d.handleMicrophoneIn(ctx)
		default:
			return nil
		}
	}

	if dir == usbip.DirOut && epNumber == EndpointOut&0x0F {
		if handled, _ := d.tryAdmitFramedOutput(out); handled {
			return nil
		}
		if len(out) >= 11 && out[0] == ReportIDOutput {
			d.mtx.Lock()
			feedback := mergeOutputReport(d.outputState, out)
			d.outputState = feedback
			d.outputSeen = true
			outputFunc := d.outputFunc
			d.mtx.Unlock()
			if outputFunc != nil {
				outputFunc(feedback)
			}
		}
	}
	if dir == usbip.DirOut && epNumber == EndpointAudioOut&0x0F {
		d.mtx.Lock()
		if d.speakerInterfaceActive && d.speakerFunc != nil && len(out) > 0 {
			// The USB/IP receive buffer is owned by the transfer handler. Give the
			// device-stream writer an immutable copy; its owned enqueue path then
			// forwards this same allocation without making a second copy. Complete
			// the synchronous enqueue under the device lock so a subsequent
			// interface or endpoint reset cannot flush the queue and then be raced
			// by a pre-reset callback publishing stale PCM afterward.
			d.speakerFunc(append([]byte(nil), out...))
		}
		d.mtx.Unlock()
		return nil
	}

	return nil
}

func (d *DualShock4) QueueMicrophonePCMFrame(frame []byte) {
	if len(frame) != USBMicrophoneClientFrameSize {
		return
	}

	d.mtx.Lock()
	if !d.microphoneInterfaceActive {
		d.mtx.Unlock()
		return
	}

	d.microphoneBuffer.QueueFrame(frame)
	d.mtx.Unlock()

	select {
	case d.microphoneSignal <- struct{}{}:
	default:
	}
}

// ResetMicrophonePCM clears capture transport state after the current API
// stream ends. The API generation coordinator suppresses this reset when that
// stream was displaced by a same-device replacement.
func (d *DualShock4) ResetMicrophonePCM() {
	d.mtx.Lock()
	d.microphoneBuffer.Reset()
	d.drainMicrophoneSignal()
	d.mtx.Unlock()
}

func (d *DualShock4) handleMicrophoneIn(ctx context.Context) []byte {
	packet := make([]byte, USBMicrophoneMaxPacketSize)
	for {
		d.mtx.Lock()
		if !d.microphoneInterfaceActive {
			d.microphoneBuffer.RecordZeroPacket()
			d.mtx.Unlock()
			return packet[:USBMicrophonePacketSize]
		}

		if actualLength, ok := d.microphoneBuffer.ReadPacket(packet); ok {
			d.mtx.Unlock()
			return packet[:actualLength]
		}
		d.mtx.Unlock()

		select {
		case <-ctx.Done():
			d.mtx.Lock()
			d.microphoneBuffer.RecordZeroPacket()
			d.mtx.Unlock()
			return packet[:USBMicrophonePacketSize]
		case <-d.microphoneSignal:
		case <-time.After(time.Millisecond):
			d.mtx.Lock()
			d.microphoneBuffer.RecordZeroPacket()
			d.mtx.Unlock()
			return packet[:USBMicrophonePacketSize]
		}
	}
}

func (d *DualShock4) drainMicrophoneSignal() {
	for {
		select {
		case <-d.microphoneSignal:
		default:
			return
		}
	}
}

func (d *DualShock4) HandleControl(bmRequestType, bRequest uint8, wValue, wIndex, wLength uint16, data []byte) ([]byte, bool) {
	if response, handled := handleAudioControlRequest(bmRequestType, bRequest, wValue, wIndex, wLength); handled {
		return response, true
	}

	reportType := uint8(wValue >> 8)
	reportID := uint8(wValue & 0xFF)

	switch bmRequestType {
	case hidClassIN:
		switch bRequest {
		case hidGetReport:
			if reportType == reportTypeInput && reportID == ReportIDInput {
				d.mtx.Lock()
				is := *d.inputState
				ms := *d.metaState
				d.mtx.Unlock()
				b := d.buildUSBInputReport(&is, &ms)
				if wLength > 0 && int(wLength) < len(b) {
					b = b[:wLength]
				}
				return b, true
			}
			if reportType == reportTypeFeature {
				if fn, ok := featureGetHandlers[reportID]; ok {
					b := fn(d)
					if wLength > 0 && int(wLength) < len(b) {
						b = b[:wLength]
					}
					return b, true
				}
			}
		case hidGetIdle:
			return []byte{0x00}, true
		case hidGetProtocol:
			return []byte{0x01}, true
		case 0x81:
			return []byte{0x00}, true
		case 0x82, 0x83, 0x84:
			return []byte{0x00, 0x00}, true
		}
	case hidClassOUT:
		if bRequest == hidSetReport {
			switch {
			case reportType == reportTypeFeature && reportID == featureIDSubcommand:
				if len(data) >= 2 {
					d.telemetrySubcommand = data[1]
				}
				return nil, true
			case reportType == reportTypeFeature && reportID == featureIDProbe:
				if len(data) >= 4 {
					d.probeSelector[0] = data[1]
					d.probeSelector[1] = data[2]
					d.probeSelector[2] = data[3]
				}
				return nil, true
			case reportType == reportTypeOutput && reportID == ReportIDOutput && len(data) >= 11:
				if handled, accepted := d.tryAdmitFramedOutput(data); handled {
					return nil, accepted
				}
				d.mtx.Lock()
				feedback := mergeOutputReport(d.outputState, data)
				d.outputState = feedback
				d.outputSeen = true
				outputFunc := d.outputFunc
				d.mtx.Unlock()
				if outputFunc != nil {
					outputFunc(feedback)
				}
				return nil, true
			}
		}
	}

	slog.Warn("DS4 control request unhandled",
		"bmRequestType", bmRequestType,
		"bRequest", bRequest,
		"reportType", reportType,
		"reportID", reportID,
		"wIndex", wIndex,
		"wLength", wLength,
		"dataLen", len(data))

	return nil, false
}

const (
	audioClassRequestSetCurrent    = 0x01
	audioClassRequestGetCurrent    = 0x81
	audioClassRequestGetMinimum    = 0x82
	audioClassRequestGetMaximum    = 0x83
	audioClassRequestGetResolution = 0x84

	audioClassEndpointOut = 0x22
	audioClassEndpointIn  = 0xA2

	audioControlSamplingFrequency = 0x01
)

// handleAudioControlRequest implements the endpoint sampling-frequency
// controls advertised by the real CUH-ZCT2 UAC1 descriptor. Windows validates
// these requests before opening the render and capture endpoints.
func handleAudioControlRequest(bmRequestType, bRequest uint8, wValue, wIndex, wLength uint16) ([]byte, bool) {
	endpoint := uint8(wIndex)
	if (endpoint != EndpointAudioOut && endpoint != EndpointMicrophoneIn) ||
		uint8(wValue>>8) != audioControlSamplingFrequency {
		return nil, false
	}

	var sampleRate int
	switch endpoint {
	case EndpointAudioOut:
		sampleRate = USBSpeakerSampleRate
	case EndpointMicrophoneIn:
		sampleRate = USBMicrophoneSampleRate
	}

	switch bmRequestType {
	case audioClassEndpointIn:
		switch bRequest {
		case audioClassRequestGetCurrent, audioClassRequestGetMinimum, audioClassRequestGetMaximum:
			response := []byte{byte(sampleRate), byte(sampleRate >> 8), byte(sampleRate >> 16)}
			if wLength < uint16(len(response)) {
				response = response[:wLength]
			}
			return response, true
		case audioClassRequestGetResolution:
			response := []byte{0x00, 0x00, 0x00}
			if wLength < uint16(len(response)) {
				response = response[:wLength]
			}
			return response, true
		}
	case audioClassEndpointOut:
		if bRequest == audioClassRequestSetCurrent {
			return nil, true
		}
	}

	return nil, false
}

// featureGetHandlers maps feature report IDs to their builder functions.
var featureGetHandlers = map[byte]func(*DualShock4) []byte{
	featureIDStatus:        (*DualShock4).featureReportStatus,
	featureIDProbeResponse: (*DualShock4).featureReportProbeResponse,
	featureIDCalibration:   (*DualShock4).featureReportCalibration,
	featureIDCalibrationBT: (*DualShock4).featureReportCalibrationBT,
	featureIDCapabilities:  (*DualShock4).featureReportCapabilities,
	featureIDSerial:        (*DualShock4).featureReportSerial,
	featureIDTelemetry:     (*DualShock4).featureReportTelemetry,
	featureIDIdentity:      (*DualShock4).featureReportIdentity,
	featureIDBoardInfo:     (*DualShock4).featureReportBoardInfo,
}

func parseOutputReport(data []byte) OutputState {
	return OutputState{
		RumbleSmall: data[4],
		RumbleLarge: data[5],
		LedRed:      data[6],
		LedGreen:    data[7],
		LedBlue:     data[8],
		FlashOn:     data[9],
		FlashOff:    data[10],
	}
}

// USB flags identify valid field groups. Resolve the partial command while
// holding mtx, before admission/commit, so every existing seven-byte client
// receives a complete state. Never change the established wire layout.
func mergeOutputReport(previous OutputState, data []byte) OutputState {
	update := parseOutputReport(data)
	if data[1]&0x01 != 0 {
		previous.RumbleSmall, previous.RumbleLarge = update.RumbleSmall, update.RumbleLarge
	}
	if data[1]&0x02 != 0 {
		previous.LedRed, previous.LedGreen, previous.LedBlue = update.LedRed, update.LedGreen, update.LedBlue
	}
	if data[1]&0x04 != 0 {
		previous.FlashOn, previous.FlashOff = update.FlashOn, update.FlashOff
	}
	return previous
}

func (d *DualShock4) featureReportTelemetry() []byte {
	d.mtx.Lock()
	defer d.mtx.Unlock()

	s := serialStringToBytes(d.metaState.SerialNumber)
	switch d.telemetrySubcommand {
	case 0x02:
		return []byte{
			featureIDTelemetry,
			s[3], s[2], s[1], s[0], s[7], s[6], s[5], s[4],
			0x00, 0x00, 0x00, 0x00, 0x00,
		}
	case 0x0B:
		return []byte{
			featureIDTelemetry,
			s[3], s[2], s[1], s[0], s[7], s[6], s[5], s[4],
			0xAC, 0xA8, 0x1B,
			0x00, 0x00,
		}
	default:
		volts := telemetryVoltageU16(d.metaState.BatteryVoltage)
		temp := telemetryTemperatureU16(d.metaState.TemperatureCelsius)
		return []byte{
			featureIDTelemetry, d.telemetrySubcommand, 0x03, 0x01, 0x00, 0x04,
			byte(volts), byte(volts >> 8),
			byte(temp), byte(temp >> 8),
			0x00, 0x00, 0x00, 0x00,
		}
	}
}

func (d *DualShock4) featureReportIdentity() []byte {
	d.mtx.Lock()
	defer d.mtx.Unlock()
	serial := serialStringToBytes(d.metaState.SerialNumber)
	firmware := ds4FirmwareVersionString()

	buildDateStr := d.metaState.BuildTime.Format("Jan 02 2006")

	report := make([]byte, 64)
	report[0] = featureIDIdentity
	copy(report[1:9], serial[:])
	copy(report[10:18], serial[:])
	copy(report[18:34], d.metaState.SerialNumber)
	copy(report[34:46], d.metaState.Board)
	copy(report[46:57], buildDateStr)
	copy(report[57:64], firmware[:7])
	return report
}

func (d *DualShock4) featureReportBoardInfo() []byte {
	report := make([]byte, 49)
	report[0] = featureIDBoardInfo

	d.mtx.Lock()
	buildDateStr := d.metaState.BuildTime.Format("Jan 02 2006")
	buildTimeStr := d.metaState.BuildTime.Format("15:04:05")
	d.mtx.Unlock()

	// Report ID precedes two 16-byte NUL-padded strings. The time starts
	// at byte 17; byte 16 still belongs to the date field.
	copy(report[1:17], buildDateStr)
	copy(report[17:33], buildTimeStr)
	binary.LittleEndian.PutUint16(report[33:35], HardwareVersionMajor)
	binary.LittleEndian.PutUint16(report[35:37], HardwareVersionMinor)
	binary.LittleEndian.PutUint32(report[37:41], SoftwareVersionMajor)
	binary.LittleEndian.PutUint16(report[41:43], SoftwareVersionMinor)

	report[47] = 1

	return report
}

func (d *DualShock4) featureReportSerial() []byte {
	d.mtx.Lock()
	serial := serialStringToBytes(d.metaState.SerialNumber)
	d.mtx.Unlock()

	report := make([]byte, 16)
	report[0] = featureIDSerial
	report[1] = serial[7]
	report[2] = serial[6]
	report[3] = serial[5]
	report[4] = serial[4]
	report[5] = serial[3]
	report[6] = serial[2]
	report[7] = serial[1]
	copy(report[8:16], serial[:])

	return report
}

func (d *DualShock4) featureReportStatus() []byte {
	d.mtx.Lock()
	defer d.mtx.Unlock()
	report := make([]byte, 5)
	report[0] = featureIDStatus
	report[1] = d.metaState.BatteryStatus & BatteryLevelMask
	report[2] = 12
	binary.LittleEndian.PutUint16(report[3:5], 664)
	return report
}

func (d *DualShock4) featureReportProbeResponse() []byte {
	b1 := d.probeSelector[0]
	b2 := d.probeSelector[1]
	b3 := d.probeSelector[2]

	report := [4]byte{featureIDProbeResponse, b1, b2, b3}

	switch {
	case b1 == 0xFF && b2 == 0x00 && b3 == 0x0C:
		report[1] = 0x01
	}

	return report[:]
}

func (d *DualShock4) featureReportCapabilities() []byte {
	report := make([]byte, 48)
	report[0] = featureIDCapabilities
	report[2] = 0x27

	// Sensor + lightbar + vibration + touchpad capability bits.
	report[4] = 0x02 | 0x04 | 0x08 | 0x40
	report[5] = 0x00 // gamepad

	binary.LittleEndian.PutUint16(report[10:12], 1)
	binary.LittleEndian.PutUint16(report[12:14], 16)
	binary.LittleEndian.PutUint16(report[14:16], 1)
	binary.LittleEndian.PutUint16(report[16:18], 8192)

	return report
}

func (d *DualShock4) featureReportCalibration() []byte {
	return d.buildCalibrationReport(featureIDCalibration)
}

func (d *DualShock4) featureReportCalibrationBT() []byte {
	return d.buildCalibrationReport(featureIDCalibrationBT)
}

func (d *DualShock4) buildCalibrationReport(id byte) []byte {
	report := make([]byte, 37)
	report[0] = id

	// 17 LE int16 fields packed sequentially from offset 1:
	// bias(pitch,yaw,roll) | gyro±(x,y,z) | speed(x,y) | accel±(x,y,z)
	for i, v := range [17]int16{
		0, 0, 0,
		1024, -1024, 1024, -1024, 1024, -1024,
		64, 64,
		8192, -8192, 8192, -8192, 8192, -8192,
	} {
		binary.LittleEndian.PutUint16(report[1+i*2:], uint16(v))
	}

	return report
}

func (d *DualShock4) buildUSBInputReport(s *InputState, m *MetaState) []byte {
	b := make([]byte, InputReportSize)

	b[0] = ReportIDInput

	b[1] = uint8(int16(s.LX) + 128)
	b[2] = uint8(int16(s.LY) + 128)
	b[3] = uint8(int16(s.RX) + 128)
	b[4] = uint8(int16(s.RY) + 128)

	usbDPad := uint8(DPadUSBNeutral)
	switch {
	case s.DPad&DPadUp != 0 && s.DPad&DPadRight != 0:
		usbDPad = DPadUSBUpRight
	case s.DPad&DPadUp != 0 && s.DPad&DPadLeft != 0:
		usbDPad = DPadUSBUpLeft
	case s.DPad&DPadDown != 0 && s.DPad&DPadRight != 0:
		usbDPad = DPadUSBDownRight
	case s.DPad&DPadDown != 0 && s.DPad&DPadLeft != 0:
		usbDPad = DPadUSBDownLeft
	case s.DPad&DPadUp != 0:
		usbDPad = DPadUSBUp
	case s.DPad&DPadDown != 0:
		usbDPad = DPadUSBDown
	case s.DPad&DPadLeft != 0:
		usbDPad = DPadUSBLeft
	case s.DPad&DPadRight != 0:
		usbDPad = DPadUSBRight
	}

	b[5] = (usbDPad & DPadMask) | (uint8(s.Buttons) & 0xF0)
	b[6] = uint8(s.Buttons >> 8)

	counter := atomic.AddUint32(&d.usbPacketCounter, 1) & 0x3F

	psTouch := uint8(0)
	if s.Buttons&ButtonPS != 0 {
		psTouch |= ButtonPSUSB
	}
	if s.Buttons&ButtonTouchpadClick != 0 {
		psTouch |= ButtonTouchpadClickUSB
	}
	b[7] = psTouch | uint8(counter<<CounterShift)

	b[8] = s.L2
	b[9] = s.R2

	ts := d.nextReportTimestamp()
	binary.LittleEndian.PutUint16(b[10:12], uint16(ts))

	binary.LittleEndian.PutUint16(b[13:15], uint16(s.GyroX))
	binary.LittleEndian.PutUint16(b[15:17], uint16(s.GyroY))
	binary.LittleEndian.PutUint16(b[17:19], uint16(s.GyroZ))

	binary.LittleEndian.PutUint16(b[19:21], uint16(s.AccelX))
	binary.LittleEndian.PutUint16(b[21:23], uint16(s.AccelY))
	binary.LittleEndian.PutUint16(b[23:25], uint16(s.AccelZ))

	b[12] = 0x09            // status: touchpad connected, no extension
	b[30] = m.BatteryStatus // low nibble = level, bit4 = cable
	b[33] = 0x01            // nvslocked
	b[34] = 0x01

	touch1Counter := uint8(0)
	if !s.Touch1Active {
		touch1Counter |= TouchInactiveMask
	}
	b[35] = touch1Counter
	encodeTouchCoords(b[36:39], s.Touch1X, s.Touch1Y)

	touch2Counter := uint8(0)
	if !s.Touch2Active {
		touch2Counter |= TouchInactiveMask
	}
	b[39] = touch2Counter
	encodeTouchCoords(b[40:43], s.Touch2X, s.Touch2Y)

	return b
}

func (d *DualShock4) nextReportTimestamp() uint32 {
	return uint32(time.Since(d.timestampBase).Nanoseconds() * 3 / 16000)
}
