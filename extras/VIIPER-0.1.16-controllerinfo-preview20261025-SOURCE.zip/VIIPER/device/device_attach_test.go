package device_test

import (
	"context"
	"sort"
	"strings"
	"testing"
	"time"

	"github.com/Alia5/VIIPER/internal/server/api"
	"github.com/Alia5/VIIPER/internal/server/api/handler"
	"github.com/Alia5/VIIPER/viiperclient"
	"github.com/Alia5/VIIPER/virtualbus"
	"github.com/stretchr/testify/assert"

	viiperTesting "github.com/Alia5/VIIPER/_testing"

	_ "github.com/Alia5/VIIPER/internal/devicecatalog" // Register devices
)

func TestDualSenseRegistryOnlyExposesV5Contract(t *testing.T) {
	var got []string
	for _, deviceType := range api.ListDeviceTypes() {
		if strings.HasPrefix(deviceType, "dualsense") {
			got = append(got, deviceType)
		}
	}
	sort.Strings(got)
	assert.Equal(t, []string{
		"dualsenseaudioonlyduplexv5",
		"dualsenseaudioonlyduplexv5events",
		"dualsenseaudioonlyduplexv5rawinputevents",
		"dualsensecombinedaudioduplexv5",
		"dualsensecombinedaudioduplexv5events",
		"dualsensecombinedaudioduplexv5rawinputevents",
		"dualsenseedgecombinedaudioduplexv5",
		"dualsenseedgecombinedaudioduplexv5events",
		"dualsenseedgecombinedaudioduplexv5rawinputevents",
		"dualsenseedgegamepadv5",
		"dualsenseedgegamepadv5rawinput",
		"dualsensegamepadv5",
		"dualsensegamepadv5rawinput",
	}, got)
}

func TestDeviceAttach(t *testing.T) {

	deviceTypes := api.ListDeviceTypes()
	assert.NotEmpty(t, deviceTypes)

	type testCase struct {
		deviceType string
	}

	cases := make([]testCase, len(deviceTypes))
	for i, dt := range deviceTypes {
		cases[i] = testCase{deviceType: dt}
	}

	for _, tc := range cases {
		t.Run(tc.deviceType, func(t *testing.T) {

			s := viiperTesting.NewTestServer(t)
			defer s.UsbServer.Close() // nolint
			defer s.ApiServer.Close() // nolint

			r := s.ApiServer.Router()
			r.Register("bus/{id}/add", handler.BusDeviceAdd(s.UsbServer, s.ApiServer))
			r.RegisterStream("bus/{busId}/{deviceid}", api.DeviceStreamHandler(s.UsbServer))

			if err := s.ApiServer.Start(); err != nil {
				t.Fatalf("Failed to start API server: %v", err)
			}
			b, err := virtualbus.NewWithBusID(1)
			if err != nil {
				t.Fatalf("Failed to create virtual bus: %v", err)
			}
			defer b.Close() // nolint
			err = s.UsbServer.AddBus(b)
			if err != nil {
				t.Fatalf("Failed to add bus to USB server: %v", err)
			}

			c := viiperclient.New(s.ApiServer.Addr())

			stream, addResp, err := c.AddDeviceAndConnect(context.Background(), b.BusID(), tc.deviceType, nil)
			if !assert.NoError(t, err) {
				t.Fatal()
			}
			assert.NotNil(t, stream)
			assert.NotNil(t, addResp)
			assert.Equal(t, tc.deviceType, addResp.Type)
			assert.Equal(t, b.BusID(), addResp.BusID)
			assert.Equal(t, "1", addResp.DevID)

			if stream != nil {
				defer stream.Close() //nolint:errcheck
			}

			usbipClient := viiperTesting.NewUsbIpClient(t, s.UsbServer.Addr())

			var devs []viiperTesting.Device
			ok := assert.Eventually(t, func() bool {
				list, err := usbipClient.ListDevices()
				if err != nil {
					return false
				}
				devs = list
				return len(devs) == 1
			}, 1*time.Second, 10*time.Millisecond)
			if !ok {
				return
			}

			imp, err := usbipClient.AttachDevice(devs[0].BusID)
			if !assert.NoError(t, err) {
				return
			}
			if !assert.NotNil(t, imp) {
				return
			}
			if imp.Conn != nil {
				defer imp.Conn.Close() // nolint
			}
			if !assert.NotNil(t, imp.Conn) {
				return
			}

		})
	}

}
