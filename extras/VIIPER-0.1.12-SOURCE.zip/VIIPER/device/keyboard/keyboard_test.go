package keyboard_test

import (
	"context"
	"io"
	"testing"
	"time"

	viiperTesting "github.com/Alia5/VIIPER/_testing"
	"github.com/Alia5/VIIPER/device/keyboard"
	"github.com/Alia5/VIIPER/internal/server/api"
	"github.com/Alia5/VIIPER/internal/server/api/handler"
	"github.com/Alia5/VIIPER/usbip"
	"github.com/Alia5/VIIPER/viiperclient"
	"github.com/Alia5/VIIPER/virtualbus"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"

	_ "github.com/Alia5/VIIPER/internal/devicecatalog" // Register devices
)

func TestInputReports(t *testing.T) {
	type testCase struct {
		name           string
		inputState     keyboard.InputState
		expectedReport []byte
	}

	cases := []testCase{
		{
			name: "No keys, no modifiers",
			inputState: keyboard.InputState{
				Modifiers: 0,
				KeyBitmap: [32]uint8{},
			},
			expectedReport: []byte{0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0},
		},
		{
			name:           "C",
			inputState:     keyboard.PressKey(keyboard.KeyC),
			expectedReport: []byte{0x00, 0x00, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
		},
		{
			name:           "CTRL+C",
			inputState:     keyboard.PressKeyWithMod(keyboard.ModLeftCtrl, keyboard.KeyC),
			expectedReport: []byte{0x01, 0x00, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
		},
		{
			name:           "SHIFT+C",
			inputState:     keyboard.PressKeyWithMod(keyboard.ModLeftShift, keyboard.KeyC),
			expectedReport: []byte{0x02, 0x00, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
		},
		{
			name:           "ALT+C",
			inputState:     keyboard.PressKeyWithMod(keyboard.ModLeftAlt, keyboard.KeyC),
			expectedReport: []byte{0x04, 0x00, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
		},
		{
			name:           "WASD",
			inputState:     keyboard.PressKey(keyboard.KeyW, keyboard.KeyA, keyboard.KeyS, keyboard.KeyD),
			expectedReport: []byte{0x00, 0x00, 0x90, 0x00, 0x40, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
		},
	}

	s := viiperTesting.NewTestServer(t)
	defer s.UsbServer.Close() // nolint
	defer s.ApiServer.Close() // nolint

	r := s.ApiServer.Router()
	r.Register("bus/{id}/add", handler.BusDeviceAdd(s.UsbServer, s.ApiServer))
	r.RegisterStream("bus/{busId}/{deviceid}", api.DeviceStreamHandler(s.UsbServer))

	if err := s.ApiServer.Start(); err != nil {
		t.Fatalf("Failed to start API server: %v", err)
	}

	b, err := virtualbus.NewWithBusID(1)
	if err != nil {
		t.Fatalf("Failed to create virtual bus: %v", err)
	}
	defer b.Close() // nolint
	_ = s.UsbServer.AddBus(b)

	client := viiperclient.New(s.ApiServer.Addr())
	stream, _, err := client.AddDeviceAndConnect(context.Background(), b.BusID(), "keyboard", nil)
	if !assert.NoError(t, err) {
		return
	}
	defer stream.Close() // nolint

	usbipClient := viiperTesting.NewUsbIpClient(t, s.UsbServer.Addr())
	devs, err := usbipClient.ListDevices()
	if !assert.NoError(t, err) {
		return
	}
	if !assert.Len(t, devs, 1) {
		return
	}
	imp, err := usbipClient.AttachDevice(devs[0].BusID)
	if !assert.NoError(t, err) {
		return
	}
	if imp != nil && imp.Conn != nil {
		defer imp.Conn.Close() // nolint
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			assert.Equal(t, tc.expectedReport, tc.inputState.BuildReport())
			if !assert.NoError(t, stream.WriteBinary(&tc.inputState)) {
				return
			}
			got, err := usbipClient.PollInputReport(imp.Conn, tc.expectedReport, viiperTesting.IntegrationTimeout)
			if !assert.NoError(t, err) {
				return
			}
			assert.Equal(t, tc.expectedReport, got)
		})
	}
}

func TestLEDs(t *testing.T) {
	type testCase struct {
		name      string
		ledMask   byte
		outPacket []byte
	}

	cases := []testCase{
		{
			name:      "off",
			ledMask:   0x00,
			outPacket: []byte{0x00},
		},
		{
			name:      "numlock",
			ledMask:   keyboard.LEDNumLock,
			outPacket: []byte{keyboard.LEDNumLock},
		},
		{
			name:      "capslock",
			ledMask:   keyboard.LEDCapsLock,
			outPacket: []byte{keyboard.LEDCapsLock},
		},
		{
			name:      "scrolllock",
			ledMask:   keyboard.LEDScrollLock,
			outPacket: []byte{keyboard.LEDScrollLock},
		},
		{
			name:    "all",
			ledMask: keyboard.LEDNumLock | keyboard.LEDCapsLock | keyboard.LEDScrollLock | keyboard.LEDCompose | keyboard.LEDKana,
			outPacket: []byte{
				keyboard.LEDNumLock | keyboard.LEDCapsLock | keyboard.LEDScrollLock | keyboard.LEDCompose | keyboard.LEDKana,
			},
		},
	}

	s := viiperTesting.NewTestServer(t)
	defer s.UsbServer.Close() // nolint
	defer s.ApiServer.Close() // nolint

	r := s.ApiServer.Router()
	r.Register("bus/{id}/add", handler.BusDeviceAdd(s.UsbServer, s.ApiServer))
	r.RegisterStream("bus/{busId}/{deviceid}", api.DeviceStreamHandler(s.UsbServer))

	if err := s.ApiServer.Start(); err != nil {
		t.Fatalf("Failed to start API server: %v", err)
	}

	b, err := virtualbus.NewWithBusID(1)
	if err != nil {
		t.Fatalf("Failed to create virtual bus: %v", err)
	}
	defer b.Close() // nolint
	_ = s.UsbServer.AddBus(b)

	client := viiperclient.New(s.ApiServer.Addr())
	stream, _, err := client.AddDeviceAndConnect(context.Background(), b.BusID(), "keyboard", nil)
	if !assert.NoError(t, err) {
		return
	}
	defer stream.Close() // nolint

	usbipClient := viiperTesting.NewUsbIpClient(t, s.UsbServer.Addr())
	devs, err := usbipClient.ListDevices()
	if !assert.NoError(t, err) {
		return
	}
	if !assert.Len(t, devs, 1) {
		return
	}
	imp, err := usbipClient.AttachDevice(devs[0].BusID)
	if !assert.NoError(t, err) {
		return
	}
	if imp != nil && imp.Conn != nil {
		defer imp.Conn.Close() // nolint
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			if !assert.NoError(t, usbipClient.Submit(imp.Conn, usbip.DirOut, 1, tc.outPacket, nil)) {
				return
			}
			var buf [1]byte
			_ = stream.SetReadDeadline(time.Now().Add(viiperTesting.IntegrationTimeout))
			_, err := io.ReadFull(stream, buf[:])
			if !assert.NoError(t, err) {
				return
			}
			assert.Equal(t, tc.ledMask, buf[0])
		})
	}
}

func TestLEDCallbackReplaysLatestHostState(t *testing.T) {
	dev, err := keyboard.New(nil)
	require.NoError(t, err)

	dev.HandleTransfer(context.Background(), 1, usbip.DirOut,
		[]byte{keyboard.LEDNumLock | keyboard.LEDCapsLock})

	gotCh := make(chan keyboard.LEDState, 1)
	dev.SetLEDCallback(func(led keyboard.LEDState) {
		gotCh <- led
	})

	select {
	case got := <-gotCh:
		assert.True(t, got.NumLock)
		assert.True(t, got.CapsLock)
		assert.False(t, got.ScrollLock)
		assert.False(t, got.Compose)
		assert.False(t, got.Kana)
	case <-time.After(viiperTesting.IntegrationTimeout):
		t.Fatal("expected late LED callback to receive latest host state")
	}
}
