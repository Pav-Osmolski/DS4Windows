package ns2pro

import (
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"net"
	"sync"
	"time"

	"github.com/Alia5/VIIPER/device"
	"github.com/Alia5/VIIPER/internal/inputpresentation"
	"github.com/Alia5/VIIPER/internal/server/api"
	"github.com/Alia5/VIIPER/usb"
)

func init() {
	api.RegisterDevice("ns2pro", &handler{})
}

type handler struct{}

var (
	serialsMu sync.Mutex
	serials   = map[string]struct{}{}
)

func (h *handler) CreateDevice(o *device.CreateOptions) (usb.Device, error) {
	if o == nil {
		o = &device.CreateOptions{}
	}

	metaState := *defaultMetaState()
	if o.DeviceSpecific != "" {
		if err := json.Unmarshal([]byte(o.DeviceSpecific), &metaState); err != nil {
			return nil, fmt.Errorf("invalid device specific JSON: %w", err)
		}
	}

	serial := metaState.SerialNumber
	if serial == "" {
		serial = DefaultSerial
	}
	serialsMu.Lock()
	if _, ok := serials[serial]; ok {
		if len(serial) < 2 {
			serial = DefaultSerial
		}
		for i := 1; i < 16; i++ {
			newSerial := fmt.Sprintf("%s%02X", serial[:len(serial)-2], i)
			if _, exists := serials[newSerial]; !exists {
				serial = newSerial
				break
			}
		}
	}

	metaState.SerialNumber = serial
	serials[serial] = struct{}{}
	serialsMu.Unlock()

	b, err := json.Marshal(metaState)
	if err != nil {
		return nil, fmt.Errorf("marshal meta state: %w", err)
	}
	o.DeviceSpecific = string(b)

	result, err := New(o)
	if err != nil {
		serialsMu.Lock()
		delete(serials, serial)
		serialsMu.Unlock()
	}
	return result, err
}

func (h *handler) StreamHandler() api.StreamHandlerFunc {
	return func(conn net.Conn, devPtr *usb.Device, logger *slog.Logger) error {
		ownsStream := false
		defer func() {
			if !ownsStream || devPtr == nil || *devPtr == nil {
				return
			}
			ns2, ok := (*devPtr).(*NS2Pro)
			if !ok {
				slog.Warn("device is not ns2pro on disconnect")
				return
			}
			serial := ns2.serialNumber()
			if serial == "" {
				return
			}
			serialsMu.Lock()
			delete(serials, serial)
			serialsMu.Unlock()
			slog.Debug("ns2pro disconnected, serial released", "serial", serial)
		}()

		if devPtr == nil || *devPtr == nil {
			return fmt.Errorf("nil device")
		}
		ns2, ok := (*devPtr).(*NS2Pro)
		if !ok {
			return fmt.Errorf("device is not ns2pro")
		}
		producerLease, acquired := ns2.acquireInputProducer()
		if !acquired {
			return fmt.Errorf("ns2pro input producer is already connected")
		}
		ownsStream = true
		defer ns2.releaseInputProducer()

		clearOutputCallback := ns2.SetOutputCallback(func(feedback OutputState) {
			data, err := feedback.MarshalBinary()
			if err != nil {
				logger.Error("failed to marshal ns2pro feedback", "error", err)
				return
			}
			if _, err := conn.Write(data); err != nil {
				logger.Error("failed to send ns2pro feedback", "error", err)
			}
		})
		defer clearOutputCallback()

		buf := make([]byte, InputWireSize)
		for {
			if _, err := io.ReadFull(conn, buf); err != nil {
				if err == io.EOF {
					logger.Info("client disconnected")
					return nil
				}
				return fmt.Errorf("read input state: %w", err)
			}
			receivedAt := time.Now()

			var state InputState
			if err := state.UnmarshalBinary(buf); err != nil {
				return fmt.Errorf("unmarshal input state: %w", err)
			}
			var disposition inputpresentation.FixedReportPublishDisposition
			producerLease, disposition = ns2.publishInputStateWithLease(
				producerLease, state, receivedAt)
			switch disposition {
			case inputpresentation.FixedReportPublishAcceptedOrdered,
				inputpresentation.FixedReportPublishAcceptedContinuous,
				inputpresentation.FixedReportPublishAcceptedResynchronization:
				continue
			case inputpresentation.FixedReportPublishFaultedOverflow,
				inputpresentation.FixedReportPublishRejectedNeutralPending,
				inputpresentation.FixedReportPublishRejectedResynchronizationRequired,
				inputpresentation.FixedReportPublishRejectedStaleProducer:
				// The lifecycle owner presents a mandatory neutral and then the
				// freshest staged complete snapshot. A stale frame at a USB
				// boundary is deliberately discarded; the returned lease is for
				// the next raw frame only.
				continue
			default:
				return fmt.Errorf("publish ns2pro input state: disposition %d",
					disposition)
			}
		}
	}
}

func (h *handler) UpdateMetaState(meta string, dev *usb.Device) error {
	ns2, ok := (*dev).(*NS2Pro)
	if !ok {
		return fmt.Errorf("%w: expected ns2pro", device.ErrWrongDeviceType)
	}

	metaState := *defaultMetaState()
	if err := json.Unmarshal([]byte(meta), &metaState); err != nil {
		return fmt.Errorf("unmarshal meta state: %w", err)
	}

	ns2.SetMetaState(metaState)
	return nil
}
