package dualsense

import "time"

const (
	DefaultVID       = 0x054C
	DefaultPIDDSEdge = 0x0DF2
	DefaultPIDDS     = 0x0CE6
)

const (
	DeviceTypeCombinedAudioDuplexV5     = "dualsensecombinedaudioduplexv5"
	DeviceTypeAudioOnlyDuplexV5         = "dualsenseaudioonlyduplexv5"
	DeviceTypeGamepadOnlyV5             = "dualsensegamepadv5"
	DeviceTypeEdgeCombinedAudioDuplexV5 = "dualsenseedgecombinedaudioduplexv5"
	DeviceTypeEdgeGamepadOnlyV5         = "dualsenseedgegamepadv5"

	// The events aliases are an explicit output-event capability boundary. They
	// retain the exact legacy 33-byte input payload for existing clients.
	DeviceTypeCombinedAudioDuplexV5Events     = "dualsensecombinedaudioduplexv5events"
	DeviceTypeAudioOnlyDuplexV5Events         = "dualsenseaudioonlyduplexv5events"
	DeviceTypeEdgeCombinedAudioDuplexV5Events = "dualsenseedgecombinedaudioduplexv5events"

	// Raw-input aliases explicitly negotiate the enhanced 53-byte input state.
	// Audio-capable variants also retain ordered output lifecycle events;
	// gamepad-only variants have no microphone interface to advertise.
	DeviceTypeCombinedAudioDuplexV5RawInputEvents     = "dualsensecombinedaudioduplexv5rawinputevents"
	DeviceTypeAudioOnlyDuplexV5RawInputEvents         = "dualsenseaudioonlyduplexv5rawinputevents"
	DeviceTypeGamepadOnlyV5RawInput                   = "dualsensegamepadv5rawinput"
	DeviceTypeEdgeCombinedAudioDuplexV5RawInputEvents = "dualsenseedgecombinedaudioduplexv5rawinputevents"
	DeviceTypeEdgeGamepadOnlyV5RawInput               = "dualsenseedgegamepadv5rawinput"
)

const (
	DefaultMACAddressDSEdge   = "A5:FE:9C:CF:92:00" // Steam reads this as serial? // TODO: not detected by all apps
	DefaultSerialNumberDSEdge = "E55E00GTD1190A500" // Byte 6 (00) is "color code" will be replaced by MetaState
	DefaultBoardStringEdge    = "HMB-010"
)

const (
	DefaultMACAddressDS   = "A5:FA:9C:CF:92:00" // Steam reads this as serial? // TODO: not detected by all apps
	DefaultSerialNumberDS = "E55700GTD1190A500" // Byte 6 (00) is "color code" will be replaced by MetaState
	DefaultBoardStringDS  = "BDM-050"
)
const (
	DefaultBatteryStatus = BatteryFullyCharged
	DefaultTemperature   = 28.0
	DefaultVoltage       = 3.8
	DefaultShellColor    = ShellColorBlack
)

var DefaultBuildTime = time.Date(2025, time.July, 4, 10, 10, 32, 0, time.UTC)

const (
	EndpointIn              = 0x84
	EndpointOut             = 0x03
	EndpointHapticsAudioOut = 0x01
	EndpointMicrophoneIn    = 0x82
)

const (
	InterfaceAudioControl = 0x00
	InterfaceHapticsAudio = 0x01
	InterfaceMicrophone   = 0x02
)

const (
	ReportIDInput  = 0x01
	ReportIDOutput = 0x02
)

const (
	InputReportSize  = 64
	OutputReportSize = 48
	InputStateSize   = 33
	// InputStateRawSize is negotiated only by the exact ...v5rawinput... device
	// aliases. It retains the legacy state at bytes 0:33, adds one flags byte,
	// then transports normalized physical DualSense report metadata without
	// changing the legacy V5 contract.
	InputStateRawSize                          = 53
	InputStateRawFlagsOffset                   = InputStateSize
	InputStatePhysicalSensorOffset             = InputStateRawFlagsOffset + 1
	InputStatePhysicalMetadataOffset           = InputStatePhysicalSensorOffset + 4
	InputStatePhysicalMetadataSize             = 15
	InputStatePhysicalMetadataValid      uint8 = 1 << 0
	InputStatePhysicalMetadataEdgeLayout uint8 = 1 << 1
	inputStateRawKnownFlags                    = InputStatePhysicalMetadataValid |
		InputStatePhysicalMetadataEdgeLayout
	StreamFrameHeaderSize    = 16
	StreamFrameMagic0        = 0x56
	StreamFrameMagic1        = 0x50
	StreamFrameMagic2        = 0x43
	StreamFrameMagic3        = 0x4D
	StreamFrameVersionV5     = 0x05
	StreamFrameInputState    = 0x01
	StreamFrameMicrophonePCM = 0x02
	StreamFrameOutputState   = 0x81
	// V5 follows the proven V5 contract. It retains atomic delivery, but
	// separates the endpoint's two clocks. Its
	// speaker tail is exactly 480 raw front-stereo S16LE frames (10 ms at the
	// native 48 kHz source clock). Rear channels independently produce one
	// 64-byte 3 kHz haptics interval for every 512 source frames. Each V5 media
	// frame consumes one completed rear interval or zero-fills that lane, while
	// state and report counters remain on the 480-frame presentation clock.
	StreamFrameAtomicAudioHaptics = 0x83
	// Completed rear-channel haptics are published immediately instead of
	// waiting for the next independent 480-frame speaker boundary. The paired
	// 0x83 media frame remains unchanged for compatibility, while V5 consumers
	// that understand this lane can remove up to one speaker interval of host
	// latency.
	StreamFrameRealtimeHaptics = 0x84
	// StreamFrameMicrophoneInterfaceState is an ordered lifecycle event. Its
	// payload is one active byte followed by the little-endian uint64 stream
	// generation established when this V5 connection attached.
	StreamFrameMicrophoneInterfaceState = 0x85
	USBMicrophoneSampleRate             = 48000
	USBMicrophoneChannels               = 2
	USBMicrophoneBytesPerSample         = 2
	USBMicrophonePacketFrames           = USBMicrophoneSampleRate / 1000
	USBMicrophonePacketSize             = USBMicrophonePacketFrames *
		USBMicrophoneChannels * USBMicrophoneBytesPerSample
	USBMicrophoneMaxPacketSize = USBMicrophonePacketSize +
		USBMicrophoneChannels*USBMicrophoneBytesPerSample
	USBMicrophoneClientFrameFrames = 480
	USBMicrophoneClientFrameSize   = USBMicrophoneClientFrameFrames *
		USBMicrophoneChannels * USBMicrophoneBytesPerSample

	OutputStateTriggerBlocksSize       = 28
	OutputStateRawReportOffset         = OutputStateTriggerBlocksSize
	OutputStateCombinedBluetoothOffset = OutputStateRawReportOffset + OutputReportSize
	OutputStateV5Size                  = OutputStateCombinedBluetoothOffset + BluetoothCombinedHapticsReportSize
)

const (
	ButtonSquare   uint32 = 0x0010
	ButtonCross    uint32 = 0x0020
	ButtonCircle   uint32 = 0x0040
	ButtonTriangle uint32 = 0x0080

	ButtonL1      uint32 = 0x0100
	ButtonR1      uint32 = 0x0200
	ButtonL2      uint32 = 0x0400
	ButtonR2      uint32 = 0x0800
	ButtonCreate  uint32 = 0x1000
	ButtonOptions uint32 = 0x2000
	ButtonL3      uint32 = 0x4000
	ButtonR3      uint32 = 0x8000

	ButtonPS       uint32 = 0x00010000
	ButtonTouchpad uint32 = 0x00020000
	ButtonMicMute  uint32 = 0x00040000

	ButtonEdgeLFn uint32 = 0x00100000
	ButtonEdgeRFn uint32 = 0x00200000
	ButtonEdgeL4  uint32 = 0x00400000
	ButtonEdgeR4  uint32 = 0x00800000
)

const validDualSenseInputButtons uint32 = ButtonSquare |
	ButtonCross |
	ButtonCircle |
	ButtonTriangle |
	ButtonL1 |
	ButtonR1 |
	ButtonL2 |
	ButtonR2 |
	ButtonCreate |
	ButtonOptions |
	ButtonL3 |
	ButtonR3 |
	ButtonPS |
	ButtonTouchpad |
	ButtonMicMute |
	ButtonEdgeLFn |
	ButtonEdgeRFn |
	ButtonEdgeL4 |
	ButtonEdgeR4

const (
	DPadUp    = 0x01
	DPadDown  = 0x02
	DPadLeft  = 0x04
	DPadRight = 0x08
)

const validDualSenseInputDPad uint8 = DPadUp | DPadDown | DPadLeft | DPadRight

const (
	DPadUSBUp        = 0x00
	DPadUSBUpRight   = 0x01
	DPadUSBRight     = 0x02
	DPadUSBDownRight = 0x03
	DPadUSBDown      = 0x04
	DPadUSBDownLeft  = 0x05
	DPadUSBLeft      = 0x06
	DPadUSBUpLeft    = 0x07
	DPadUSBNeutral   = 0x08
)

const DPadMask uint8 = 0x0F

// Gyro/Accel scale factors matching the USB report domain.
//
//	Gyro: BMI323 ±2000 dps passthrough = 16.384 LSB/dps
//	Accel: BMI323 4096 LSB/g × ScaleAccel(×2) = 8192 LSB/g = 835.07 LSB/(m/s²)
const (
	GyroCountsPerDps  = 16.384
	AccelCountsPerMS2 = 835.07 // 8192 / 9.81
)

const (
	DefaultAccelXRaw int16 = 0
	DefaultAccelYRaw int16 = 0
	DefaultAccelZRaw int16 = -8192 // -1g (8192 counts/g)
)

// Touchpad dimensions.
const (
	TouchpadMinX uint16 = 0
	TouchpadMinY uint16 = 0
	TouchpadMaxX uint16 = 1920
	TouchpadMaxY uint16 = 1080

	TouchInactiveMask uint8 = 0x80
)

const DeltaTimeNS = 333

const (
	BatteryFullyCharged = 0x2A // Status=0x2 (Full), Level=0xA (100%)
)

const (
	hidClassIN  uint8 = 0xA1
	hidClassOUT uint8 = 0x21
)

const (
	hidGetReport   uint8 = 0x01
	hidGetIdle     uint8 = 0x02
	hidGetProtocol uint8 = 0x03
	hidSetReport   uint8 = 0x09
)

const (
	reportTypeInput   uint8 = 0x01
	reportTypeOutput  uint8 = 0x02
	reportTypeFeature uint8 = 0x03
)

const (
	featureIDCalibration     uint8 = 0x05
	featureIDPairing         uint8 = 0x09
	featureIDFirmware        uint8 = 0x20
	featureIDCommand         uint8 = 0x80
	featureIDCommandResponse uint8 = 0x81
)

const (
	subcmdSerial  uint8 = 0x01
	subcmdStatus  uint8 = 0x03
	subcmdSensors uint8 = 0x04
)

const (
	HardwareType    uint8  = 0x03
	HwInfo          uint32 = 0x01000208
	FirmwareVersion uint16 = 0x0630
)

const (
	ShellColorWhite                  = "00"
	ShellColorBlack                  = "01"
	ShellColorCosmicRed              = "02"
	ShellColorNovaPink               = "03"
	ShellColorGalacticPurple         = "04"
	ShellColorStarlightBlue          = "05"
	ShellColorGreyCamouflage         = "06"
	ShellColorVolcanicRed            = "07"
	ShellColorSterlingSilver         = "08"
	ShellColorCobaltBlue             = "09"
	ShellColorChromaTeal             = "10"
	ShellColorChromaIndigo           = "11"
	ShellColorChromaPearl            = "12"
	ShellColorAnniversary30th        = "30"
	ShellColorGodOfWarRagnarok       = "Z1"
	ShellColorSpiderMan2             = "Z2"
	ShellColorAstroBot               = "Z3"
	ShellColorFortnite               = "Z4"
	ShellColorMonsterHunterWilds     = "Z5"
	ShellColorTheLastOfUs            = "Z6"
	ShellColorGhostOfYotei           = "Z7"
	ShellColorIconBlueLimitedEdition = "ZB"
	ShellColorAstroBotJoyfulEdition  = "ZC"
	ShellColorGenshinImpact          = "ZE"
)
