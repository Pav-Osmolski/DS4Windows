package generator

import (
	"fmt"
	"log/slog"
	"os"
	"path/filepath"

	"github.com/Alia5/VIIPER/internal/codegen/generator/cpp"
	"github.com/Alia5/VIIPER/internal/codegen/generator/csharp"
	"github.com/Alia5/VIIPER/internal/codegen/generator/rust"
	"github.com/Alia5/VIIPER/internal/codegen/generator/typescript"
	"github.com/Alia5/VIIPER/internal/codegen/meta"
	"github.com/Alia5/VIIPER/internal/codegen/scanner"
)

type Generator struct {
	outputDir string
	logger    *slog.Logger
}

type LanguageGenerator func(logger *slog.Logger, outputDir string, md *meta.Metadata) error

var generators = map[string]LanguageGenerator{
	"cpp":        cpp.Generate,
	"csharp":     csharp.Generate,
	"rust":       rust.Generate,
	"typescript": typescript.Generate,
}

func New(outputDir string, logger *slog.Logger) *Generator {
	return &Generator{
		outputDir: outputDir,
		logger:    logger,
	}
}

func (g *Generator) GenAll() error {
	for lang := range generators {
		if err := g.GenerateLang(lang); err != nil {
			return fmt.Errorf("generate %s client library: %w", lang, err)
		}
	}
	return nil
}

func (g *Generator) GenerateLang(lang string) error {
	gen, ok := generators[lang]
	if !ok {
		var supported []string
		for k := range generators {
			supported = append(supported, k)
		}
		return fmt.Errorf("unsupported language '%s' (supported: %v)", lang, supported)
	}

	g.logger.Info("Generating client library", "language", lang)

	md, err := g.ScanAll()
	if err != nil {
		return err
	}

	outputPath := filepath.Join(g.outputDir, lang)
	if err := os.MkdirAll(outputPath, 0o755); err != nil {
		return fmt.Errorf("failed to create %s output directory: %w", lang, err)
	}

	if err := gen(g.logger, outputPath, md); err != nil {
		return err
	}

	g.logger.Info("Client library generation complete", "language", lang, "output", outputPath)
	return nil
}

func (g *Generator) ScanAll() (*meta.Metadata, error) {
	requiredPaths := []string{"internal/cmd", "viipertypes", "device"}
	for _, path := range requiredPaths {
		if _, err := os.Stat(path); os.IsNotExist(err) {
			return nil, fmt.Errorf("codegen requires VIIPER source code and must be run from the viiper module directory: missing '%s'", path)
		}
	}

	g.logger.Info("Scanning codebase for metadata")

	md := &meta.Metadata{
		DevicePackages: make(map[string]*scanner.DeviceConstants),
		DeviceStructs:  make(map[string][]scanner.DTOSchema),
		CTypeNames:     make(map[string]string),
	}

	g.logger.Debug("Scanning API routes")
	routes, err := scanner.ScanRoutesInPackage("internal/cmd")
	if err != nil {
		return nil, fmt.Errorf("failed to scan routes: %w", err)
	}
	md.Routes = routes
	g.logger.Info("Found API routes", "count", len(routes))

	g.logger.Debug("Scanning DTOs")
	dtos, err := scanner.ScanDTOsInPackage("viipertypes")
	if err != nil {
		return nil, fmt.Errorf("failed to scan DTOs: %w", err)
	}
	md.DTOs = dtos
	g.logger.Info("Found DTOs", "count", len(dtos))

	md.CTypeNames = make(map[string]string)
	for _, dto := range dtos {
		if dto.Name == "Device" {
			md.CTypeNames["Device"] = "device_info"
		}
	}

	g.logger.Debug("Discovering device packages")
	deviceBaseDir := "device"
	devicePaths, err := discoverDevicePackagePaths(deviceBaseDir)
	if err != nil {
		return nil, fmt.Errorf("failed to read device directory: %w", err)
	}

	for _, devicePath := range devicePaths {
		deviceName := filepath.Base(devicePath)

		g.logger.Debug("Scanning device package", "device", deviceName)
		deviceConsts, err := scanner.ScanDeviceConstants(devicePath)
		if err != nil {
			g.logger.Warn("Failed to scan device package", "device", deviceName, "error", err)
			continue
		}

		md.DevicePackages[deviceName] = deviceConsts

		deviceStructs, err := scanner.ScanDeviceStructs(devicePath)
		if err != nil {
			g.logger.Warn("Failed to scan device structs", "device", deviceName, "error", err)
		} else {
			md.DeviceStructs[deviceName] = deviceStructs
		}

		g.logger.Info("Scanned device package",
			"device", deviceName,
			"constants", len(deviceConsts.Constants),
			"maps", len(deviceConsts.Maps),
			"json_structs", len(md.DeviceStructs[deviceName]))
	}

	g.logger.Debug("Scanning viiper:wire tags")
	wireTags, err := scanner.ScanWireTags(devicePaths)
	if err != nil {
		return nil, fmt.Errorf("failed to scan wire tags: %w", err)
	}
	md.WireTags = wireTags
	g.logger.Info("Scanned wire tags", "devices", len(wireTags.Tags))

	g.logger.Debug("Enriching routes with handler arg info")
	enriched, err := scanner.EnrichRoutesWithHandlerInfo(md.Routes, "internal/server/api/handler")
	if err != nil {
		return nil, fmt.Errorf("failed to enrich routes: %w", err)
	}
	md.Routes = enriched

	return md, nil
}

func discoverDevicePackagePaths(deviceBaseDir string) ([]string, error) {
	entries, err := os.ReadDir(deviceBaseDir)
	if err != nil {
		return nil, err
	}

	devicePaths := make([]string, 0, len(entries))
	for _, entry := range entries {
		// Go's internal directory contains implementation-only helpers, not a
		// virtual device API that client libraries should expose.
		if !entry.IsDir() || entry.Name() == "internal" {
			continue
		}

		devicePaths = append(devicePaths, filepath.Join(deviceBaseDir, entry.Name()))
	}

	return devicePaths, nil
}
