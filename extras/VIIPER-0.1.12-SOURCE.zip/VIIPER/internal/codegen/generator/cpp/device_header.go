package cpp

import (
	"fmt"
	"log/slog"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"text/template"

	"github.com/Alia5/VIIPER/internal/codegen/common"
	"github.com/Alia5/VIIPER/internal/codegen/meta"
	"github.com/Alia5/VIIPER/internal/codegen/scanner"
)

const deviceHeaderTemplate = `{{.Header}}
#pragma once

#include "../error.hpp"
#include "../detail/json.hpp"
#include <cstdint>
#include <vector>
{{- if or .HasMaps .HasFixedWireArrays}}
#include <array>
{{- end}}
{{- if or .HasMaps .HasDeviceSpecific}}
#include <string_view>
#include <algorithm>
#include <optional>
{{- end}}
{{- if .HasMaps}}
#include <unordered_map>
#include <unordered_set>
{{- end}}

namespace viiper {
namespace {{camelcase .DeviceName}} {

// ============================================================================
// Constants
// ============================================================================
{{if gt .OutputSize 0}}
constexpr std::size_t OUTPUT_SIZE = {{.OutputSize}};
{{end}}
{{- range .Constants}}
constexpr std::uint64_t {{.Name}} = {{.Value}};
{{- end}}

{{if .HasDeviceSpecific}}
// ============================================================================
// Device-specific typed helpers
// ============================================================================
{{range .DeviceStructs}}
struct {{.Name}} {
{{- range .Fields}}
	{{fieldcpptype .}} {{.Name}}{};
{{- end}}

	static {{.Name}} from_map(const json_type& j) {
		{{.Name}} result;
{{- range .Fields}}
{{- if and .Optional (eq .TypeKind "map")}}
		if (j.contains("{{.JSONName}}") && !j["{{.JSONName}}"].is_null()) {
			result.{{.Name}} = j["{{.JSONName}}"];
		} else {
			result.{{.Name}} = std::nullopt;
		}
{{- else if .Optional}}
		result.{{.Name}} = detail::get_optional_field<{{fieldcpptype . | unwrapOptional}}>(j, "{{.JSONName}}");
{{- else if eq .TypeKind "slice"}}
		result.{{.Name}} = detail::get_array<{{cpptype .Type | sliceElementType}}>(j, "{{.JSONName}}");
{{- else if eq .TypeKind "map"}}
		if (j.contains("{{.JSONName}}")) {
			result.{{.Name}} = j["{{.JSONName}}"];
		}
{{- else if isCustomType .Type}}
		if (j.contains("{{.JSONName}}")) {
			result.{{.Name}} = {{cpptype .Type}}::from_json(j["{{.JSONName}}"]);
		}
{{- else}}
		result.{{.Name}} = j.value("{{.JSONName}}", {{cpptype .Type}}{});
{{- end}}
{{- end}}
		return result;
	}

	[[nodiscard]] json_type to_map() const {
		json_type j;
{{- range .Fields}}
{{- if .Optional}}
	if ({{.Name}}.has_value()) {
	    j["{{.JSONName}}"] = {{.Name}}.value();
		}
{{- else if eq .TypeKind "slice"}}
		{
			json_type arr = json_type::array();
	    for (const auto& item : {{.Name}}) {
				{{- if isCustomType .Type}}
				arr.push_back(item.to_json());
				{{- else}}
				arr.push_back(item);
				{{- end}}
			}
			j["{{.JSONName}}"] = std::move(arr);
		}
{{- else}}
	j["{{.JSONName}}"] = {{.Name}};
{{- end}}
{{- end}}
		return j;
	}
};

{{end}}
{{end}}
{{range .Maps}}
{{- if and (isByteKeyMap .KeyType) (hasCharLiteralKeys .Entries)}}
{{- if eq .ValueType "bool"}}
{{- $mapName := toScreamingSnakeCase .Name}}
inline const std::unordered_set<std::uint8_t> {{$mapName}} = {
{{- range $entry := sortedEntries .Entries}}
    {{formatKey $entry.Key true}},
{{- end}}
};
{{- else}}
{{- $mapName := toScreamingSnakeCase .Name}}
{{- $valueType := .ValueType}}
inline const std::unordered_map<std::uint8_t, {{cpptype $valueType}}> {{$mapName}} = {
{{- range $entry := sortedEntries .Entries}}
    { {{formatKey $entry.Key true}}, static_cast<{{cpptype $valueType}}>({{formatValue $entry.Value}}) },
{{- end}}
};
{{- end}}
{{- else if eq .ValueType "string"}}
{{- $mapName := toScreamingSnakeCase .Name}}
{{- $entries := sortedEntries .Entries}}
inline constexpr std::array<std::pair<std::uint64_t, std::string_view>, {{len $entries}}> {{$mapName}} = {{"{"}}{{"{"}}
{{- range $i, $e := $entries}}
    { {{formatKey $e.Key false}}, "{{$e.Value}}" }{{if not (isLast $i $entries)}},{{end}}
{{- end}}
}{{"}"}};

[[nodiscard]] inline std::optional<std::string_view> {{camelcase .Name}}(std::uint64_t key) noexcept {
    auto it = std::lower_bound({{$mapName}}.begin(), {{$mapName}}.end(), key,
        [](const auto& p, std::uint64_t k) { return p.first < k; });
    if (it != {{$mapName}}.end() && it->first == key) {
        return it->second;
    }
    return std::nullopt;
}
{{- else if isNumericMapVal .ValueType}}
{{- $mapName := .Name}}
{{- range $entry := sortedEntries .Entries}}
constexpr std::uint64_t {{$mapName}}_{{$entry.Key}} = {{formatValue $entry.Value}};
{{- end}}
{{- end}}
{{end}}
{{if .HasInput}}
{{$fields := wireFields .DeviceName "c2s"}}
// ============================================================================
// Input: Client -> Device
// ============================================================================

struct Input {
{{- range $fields}}
{{- if isArrayType .Type}}
{{- if isFixedArrayType .Type}}
	std::array<{{cpptype (baseType .Type)}}, {{fixedArrayLen .Type}}> {{camelcase .Name}}{};
{{- else}}
	std::vector<{{cpptype (baseType .Type)}}> {{camelcase .Name}};
{{- end}}
{{- else if not (isCountField $fields .Name)}}
    {{cpptype .Type}} {{camelcase .Name}} = 0;
{{- end}}
{{- end}}

    [[nodiscard]] std::vector<std::uint8_t> to_bytes() const {
        std::vector<std::uint8_t> buf;
{{- range $fields}}
{{- if isArrayType .Type}}
	{{- $abt := baseType .Type}}
	{{- if isFixedArrayType .Type}}
		for (std::size_t i = 0; i < static_cast<std::size_t>({{fixedArrayLen .Type}}); i++) {
		    const auto v = {{camelcase .Name}}[i];
	{{- if eq $abt "u8"}}
		    buf.push_back(static_cast<std::uint8_t>(v));
	{{- else if eq $abt "i8"}}
		    buf.push_back(static_cast<std::uint8_t>(static_cast<std::int8_t>(v)));
	{{- else if or (eq $abt "u16") (eq $abt "i16")}}
		    buf.push_back(static_cast<std::uint8_t>(v & 0xFF));
		    buf.push_back(static_cast<std::uint8_t>((v >> 8) & 0xFF));
	{{- else if or (eq $abt "u32") (eq $abt "i32")}}
		    buf.push_back(static_cast<std::uint8_t>(v & 0xFF));
		    buf.push_back(static_cast<std::uint8_t>((v >> 8) & 0xFF));
		    buf.push_back(static_cast<std::uint8_t>((v >> 16) & 0xFF));
		    buf.push_back(static_cast<std::uint8_t>((v >> 24) & 0xFF));
	{{- end}}
		}
	{{- else}}
		buf.push_back(static_cast<std::uint8_t>({{camelcase .Name}}.size()));
		for (const auto& v : {{camelcase .Name}}) {
	{{- if eq $abt "u8"}}
		    buf.push_back(static_cast<std::uint8_t>(v));
	{{- else if eq $abt "i8"}}
		    buf.push_back(static_cast<std::uint8_t>(static_cast<std::int8_t>(v)));
	{{- else if or (eq $abt "u16") (eq $abt "i16")}}
		    buf.push_back(static_cast<std::uint8_t>(v & 0xFF));
		    buf.push_back(static_cast<std::uint8_t>((v >> 8) & 0xFF));
	{{- else if or (eq $abt "u32") (eq $abt "i32")}}
		    buf.push_back(static_cast<std::uint8_t>(v & 0xFF));
		    buf.push_back(static_cast<std::uint8_t>((v >> 8) & 0xFF));
		    buf.push_back(static_cast<std::uint8_t>((v >> 16) & 0xFF));
		    buf.push_back(static_cast<std::uint8_t>((v >> 24) & 0xFF));
	{{- end}}
		}
	{{- end}}
{{- else if not (isCountField $fields .Name)}}
{{- $bt := .Type}}
{{- if eq $bt "u8"}}
        buf.push_back({{camelcase .Name}});
{{- else if eq $bt "i8"}}
        buf.push_back(static_cast<std::uint8_t>({{camelcase .Name}}));
{{- else if or (eq $bt "u16") (eq $bt "i16")}}
        buf.push_back(static_cast<std::uint8_t>({{camelcase .Name}} & 0xFF));
        buf.push_back(static_cast<std::uint8_t>(({{camelcase .Name}} >> 8) & 0xFF));
{{- else if or (eq $bt "u32") (eq $bt "i32")}}
        buf.push_back(static_cast<std::uint8_t>({{camelcase .Name}} & 0xFF));
        buf.push_back(static_cast<std::uint8_t>(({{camelcase .Name}} >> 8) & 0xFF));
        buf.push_back(static_cast<std::uint8_t>(({{camelcase .Name}} >> 16) & 0xFF));
        buf.push_back(static_cast<std::uint8_t>(({{camelcase .Name}} >> 24) & 0xFF));
{{- end}}
{{- end}}
{{- end}}
        return buf;
    }
};
{{end}}
{{if .HasOutput}}
{{$fields := wireFields .DeviceName "s2c"}}
// ============================================================================
// Output: Device -> Client
// ============================================================================

struct Output {
{{- range $fields}}
{{- if isArrayType .Type}}
{{- if isFixedArrayType .Type}}
	std::array<{{cpptype (baseType .Type)}}, {{fixedArrayLen .Type}}> {{camelcase .Name}}{};
{{- else}}
	std::vector<{{cpptype (baseType .Type)}}> {{camelcase .Name}};
{{- end}}
{{- else}}
    {{cpptype .Type}} {{camelcase .Name}} = 0;
{{- end}}
{{- end}}

    static Result<Output> from_bytes(const std::uint8_t* data, std::size_t len) {
        Output result;
        std::size_t offset = 0;
{{- range $fields}}
{{- if isArrayType .Type}}
{{- if isFixedArrayType .Type}}
{{- $bt := baseType .Type}}
	for (std::size_t i = 0; i < static_cast<std::size_t>({{fixedArrayLen .Type}}); i++) {
{{- if eq $bt "u8"}}
	    if (offset >= len) return Error("buffer too short");
	    result.{{camelcase .Name}}[i] = data[offset++];
{{- else if eq $bt "i8"}}
	    if (offset >= len) return Error("buffer too short");
	    result.{{camelcase .Name}}[i] = static_cast<std::int8_t>(data[offset++]);
{{- else if eq $bt "u16"}}
	    if (offset + 2 > len) return Error("buffer too short");
	    result.{{camelcase .Name}}[i] = data[offset] | (static_cast<std::uint16_t>(data[offset + 1]) << 8);
	    offset += 2;
{{- else if eq $bt "i16"}}
	    if (offset + 2 > len) return Error("buffer too short");
	    result.{{camelcase .Name}}[i] = static_cast<std::int16_t>(data[offset] | (static_cast<std::uint16_t>(data[offset + 1]) << 8));
	    offset += 2;
{{- else if eq $bt "u32"}}
	    if (offset + 4 > len) return Error("buffer too short");
	    result.{{camelcase .Name}}[i] = data[offset] | (static_cast<std::uint32_t>(data[offset + 1]) << 8) |
					   (static_cast<std::uint32_t>(data[offset + 2]) << 16) | (static_cast<std::uint32_t>(data[offset + 3]) << 24);
	    offset += 4;
{{- else if eq $bt "i32"}}
	    if (offset + 4 > len) return Error("buffer too short");
	    result.{{camelcase .Name}}[i] = static_cast<std::int32_t>(data[offset] | (static_cast<std::uint32_t>(data[offset + 1]) << 8) |
					   (static_cast<std::uint32_t>(data[offset + 2]) << 16) | (static_cast<std::uint32_t>(data[offset + 3]) << 24));
	    offset += 4;
{{- end}}
	}
{{- else}}
	return Error("variable-length output arrays are not supported");
{{- end}}
{{- else if eq .Type "u8"}}
        if (offset >= len) return Error("buffer too short");
        result.{{camelcase .Name}} = data[offset++];
{{- else if eq .Type "i8"}}
        if (offset >= len) return Error("buffer too short");
        result.{{camelcase .Name}} = static_cast<std::int8_t>(data[offset++]);
{{- else if eq .Type "u16"}}
        if (offset + 2 > len) return Error("buffer too short");
        result.{{camelcase .Name}} = data[offset] | (static_cast<std::uint16_t>(data[offset + 1]) << 8);
        offset += 2;
{{- else if eq .Type "i16"}}
        if (offset + 2 > len) return Error("buffer too short");
        result.{{camelcase .Name}} = static_cast<std::int16_t>(data[offset] | (static_cast<std::uint16_t>(data[offset + 1]) << 8));
        offset += 2;
{{- else if eq .Type "u32"}}
        if (offset + 4 > len) return Error("buffer too short");
        result.{{camelcase .Name}} = data[offset] | (static_cast<std::uint32_t>(data[offset + 1]) << 8) |
                                     (static_cast<std::uint32_t>(data[offset + 2]) << 16) | (static_cast<std::uint32_t>(data[offset + 3]) << 24);
        offset += 4;
{{- else if eq .Type "i32"}}
        if (offset + 4 > len) return Error("buffer too short");
        result.{{camelcase .Name}} = static_cast<std::int32_t>(data[offset] | (static_cast<std::uint32_t>(data[offset + 1]) << 8) |
                                     (static_cast<std::uint32_t>(data[offset + 2]) << 16) | (static_cast<std::uint32_t>(data[offset + 3]) << 24));
        offset += 4;
{{- end}}
{{- end}}
        (void)offset; // suppress unused warning
        return result;
    }
};
{{end}}

} // namespace {{camelcase .DeviceName}}
} // namespace viiper
`

func generateDeviceHeader(logger *slog.Logger, devicesDir, deviceName string, md *meta.Metadata) error {
	logger.Debug("Generating device header", "device", deviceName)
	outputFile := filepath.Join(devicesDir, deviceName+".hpp")

	devicePkg, ok := md.DevicePackages[deviceName]
	if !ok {
		return fmt.Errorf("device package %s not found in metadata", deviceName)
	}

	hasInput := md.WireTags != nil && md.WireTags.HasDirection(deviceName, "c2s")
	hasOutput := md.WireTags != nil && md.WireTags.HasDirection(deviceName, "s2c")

	funcs := tplFuncs(md)
	funcs["isLast"] = func(i int, entries []common.MapEntry) bool {
		return i == len(entries)-1
	}

	tmpl := template.Must(template.New("device").Funcs(funcs).Parse(deviceHeaderTemplate))

	f, err := os.Create(outputFile)
	if err != nil {
		return fmt.Errorf("create device header: %w", err)
	}
	defer f.Close() //nolint:errcheck

	hasMaps := false
	for _, m := range devicePkg.Maps {
		// Include byte-key maps (like CharToKey, ShiftChars) and string-value maps
		if isByteKeyMap(m.KeyType) || m.ValueType == "string" {
			hasMaps = true
			break
		}
	}

	// Calculate OUTPUT_SIZE from s2c wire tag
	outputSize := 0
	if md.WireTags != nil {
		if s2cTag := md.WireTags.GetTag(deviceName, "s2c"); s2cTag != nil {
			outputSize = common.CalculateOutputSize(s2cTag)
		}
	}

	hasFixedWireArrays := false
	if md.WireTags != nil {
		if c2sTag := md.WireTags.GetTag(deviceName, "c2s"); c2sTag != nil {
			for _, f := range c2sTag.Fields {
				if idx := strings.Index(f.Type, "*"); idx >= 0 {
					if _, err := strconv.Atoi(f.Type[idx+1:]); err == nil {
						hasFixedWireArrays = true
						break
					}
				}
			}
		}
		if !hasFixedWireArrays {
			if s2cTag := md.WireTags.GetTag(deviceName, "s2c"); s2cTag != nil {
				for _, f := range s2cTag.Fields {
					if idx := strings.Index(f.Type, "*"); idx >= 0 {
						if _, err := strconv.Atoi(f.Type[idx+1:]); err == nil {
							hasFixedWireArrays = true
							break
						}
					}
				}
			}
		}
	}

	constants := make([]scanner.ConstantInfo, 0, len(devicePkg.Constants))
	for _, c := range devicePkg.Constants {
		if !common.IsIntegerConst(c.Value, c.Type) {
			continue
		}
		constants = append(constants, c)
	}

	data := struct {
		Header             string
		DeviceName         string
		Constants          []scanner.ConstantInfo
		DeviceStructs      []scanner.DTOSchema
		Maps               []scanner.MapInfo
		HasInput           bool
		HasOutput          bool
		HasMaps            bool
		HasDeviceSpecific  bool
		HasFixedWireArrays bool
		OutputSize         int
	}{
		Header:             writeFileHeader(),
		DeviceName:         deviceName,
		Constants:          constants,
		DeviceStructs:      md.DeviceStructs[deviceName],
		Maps:               devicePkg.Maps,
		HasInput:           hasInput,
		HasOutput:          hasOutput,
		HasMaps:            hasMaps,
		HasDeviceSpecific:  len(md.DeviceStructs[deviceName]) > 0,
		HasFixedWireArrays: hasFixedWireArrays,
		OutputSize:         outputSize,
	}

	if err := tmpl.Execute(f, data); err != nil {
		return fmt.Errorf("execute device template: %w", err)
	}

	logger.Info("Generated device header", "device", deviceName, "file", outputFile)
	return nil
}
