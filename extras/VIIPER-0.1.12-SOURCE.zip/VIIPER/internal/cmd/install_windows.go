//go:build windows

package cmd

import (
	"bufio"
	"bytes"
	"errors"
	"fmt"
	"log/slog"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/Alia5/VIIPER/internal/configpaths"
	"golang.org/x/sys/windows/registry"
)

const (
	runKeyPath       = `Software\Microsoft\Windows\CurrentVersion\Run`
	runValueKey      = "VIIPER"
	runScheduledTask = "RunVIIPER"
)

func install(logger *slog.Logger) error {
	if os.Getenv("VIIPER_DEVELOPER_STANDALONE") != "1" {
		return errors.New("standalone VIIPER startup registration is developer-only on Windows; use the signed DS4Windows installer or its built-in VIIPER repair so one verified owner manages VIIPER and USB-IP")
	}
	if err := requireUSBIPRuntime(); err != nil {
		return err
	}
	scheduledExe, err := currentScheduledTaskExe()
	if err != nil {
		return fmt.Errorf("failed to inspect legacy %s scheduled task: %w", runScheduledTask, err)
	}
	if err := removeScheduledTask(); err != nil {
		return fmt.Errorf("failed to remove legacy %s scheduled task: %w", runScheduledTask, err)
	}
	if scheduledExe != "" {
		if err := killProcessesByExe(scheduledExe, logger); err != nil {
			return fmt.Errorf("failed to stop legacy scheduled VIIPER instance: %w", err)
		}
	}

	exePath, err := currentExecutable()
	if err != nil {
		return err
	}

	previousExe, err := currentAutorunExe()
	if err != nil {
		return err
	}

	cfgDir, err := configpaths.DefaultConfigDir()
	if err != nil {
		return fmt.Errorf("failed to resolve config dir: %w", err)
	}
	logFile := filepath.Join(cfgDir, "viiper.log")
	if err := os.MkdirAll(cfgDir, 0o755); err != nil {
		return fmt.Errorf("failed to create log directory %s: %w", cfgDir, err)
	}

	value := fmt.Sprintf("\"%s\" server --log.file \"%s\"", exePath, logFile)
	key, _, err := registry.CreateKey(registry.CURRENT_USER, runKeyPath, registry.ALL_ACCESS)
	if err != nil {
		return err
	}
	defer key.Close() //nolint:errcheck

	if err := key.SetStringValue(runValueKey, value); err != nil {
		return err
	}

	if previousExe != "" {
		if err := killProcessesByExe(previousExe, logger); err != nil {
			return fmt.Errorf("failed to stop previous autorun instance: %w", err)
		}
	}

	if err := exec.Command(exePath, "server", "--log.file", logFile).Start(); err != nil {
		return fmt.Errorf("failed to start server: %w", err)
	}

	logger.Info("VIIPER install completed for Windows autorun", "exe", exePath, "logFile", logFile)
	return nil
}

func uninstall(logger *slog.Logger) error {
	autorunExe, err := currentAutorunExe()
	if err != nil {
		return err
	}
	scheduledExe, err := currentScheduledTaskExe()
	if err != nil {
		return fmt.Errorf("failed to inspect %s scheduled task: %w", runScheduledTask, err)
	}
	if err := removeScheduledTask(); err != nil {
		return fmt.Errorf("failed to remove %s scheduled task; run uninstall as administrator: %w", runScheduledTask, err)
	}
	if scheduledExe != "" {
		if err := killProcessesByExe(scheduledExe, logger); err != nil {
			return fmt.Errorf("failed to stop scheduled VIIPER instance: %w", err)
		}
	}

	key, err := registry.OpenKey(registry.CURRENT_USER, runKeyPath, registry.SET_VALUE)
	if err != nil {
		if !errors.Is(err, registry.ErrNotExist) {
			return err
		}
	} else {
		defer key.Close() //nolint:errcheck

		if err := key.DeleteValue(runValueKey); err != nil {
			if !errors.Is(err, registry.ErrNotExist) {
				return err
			}
		}
	}

	if autorunExe != "" {
		if err := killProcessesByExe(autorunExe, logger); err != nil {
			return fmt.Errorf("failed to stop autorun instance: %w", err)
		}
	}

	currentExe, currentErr := currentExecutable()
	if currentErr == nil && !strings.EqualFold(currentExe, autorunExe) {
		if err := killProcessesByExe(currentExe, logger); err != nil {
			return fmt.Errorf("failed to stop installed VIIPER instance: %w", err)
		}
	}

	logger.Info("VIIPER startup entries removed and server stopped")
	return nil
}

func currentScheduledTaskExe() (string, error) {
	script := fmt.Sprintf(
		"$ErrorActionPreference='Stop';$t=Get-ScheduledTask -TaskName '%s' -ErrorAction SilentlyContinue;if($null -eq $t){exit 0};$a=@($t.Actions);if($a.Count -ne 1){throw 'scheduled task must contain exactly one action'};$a[0].Execute",
		runScheduledTask,
	)
	output, err := exec.Command("powershell", "-NoProfile", "-NonInteractive", "-Command", script).CombinedOutput()
	if err != nil {
		return "", fmt.Errorf("scheduled task query failed: %w: %s", err, strings.TrimSpace(string(output)))
	}
	path := strings.Trim(strings.TrimSpace(string(output)), `"`)
	if path == "" {
		return "", nil
	}
	path = filepath.Clean(path)
	if !strings.EqualFold(filepath.Base(path), "viiper.exe") {
		return "", fmt.Errorf("%s action is not a VIIPER executable: %s", runScheduledTask, path)
	}
	return path, nil
}

func removeScheduledTask() error {
	// Get-ScheduledTask makes absence distinguishable from an access-denied
	// deletion. Never report uninstall success while a highest-privilege task
	// can silently start VIIPER again at the next logon.
	script := fmt.Sprintf(
		"$ErrorActionPreference='Stop';$t=Get-ScheduledTask -TaskName '%s' -ErrorAction SilentlyContinue;if($null -eq $t){exit 0};Unregister-ScheduledTask -TaskName '%s' -Confirm:$false -ErrorAction Stop;if(Get-ScheduledTask -TaskName '%s' -ErrorAction SilentlyContinue){throw 'scheduled task still exists'}",
		runScheduledTask,
		runScheduledTask,
		runScheduledTask,
	)
	output, err := exec.Command("powershell", "-NoProfile", "-NonInteractive", "-Command", script).CombinedOutput()
	if err != nil {
		return fmt.Errorf("scheduled task removal failed: %w: %s", err, strings.TrimSpace(string(output)))
	}
	return nil
}

func currentAutorunExe() (string, error) {
	key, err := registry.OpenKey(registry.CURRENT_USER, runKeyPath, registry.QUERY_VALUE)
	if err != nil {
		if errors.Is(err, registry.ErrNotExist) {
			return "", nil
		}
		return "", err
	}
	defer key.Close() //nolint:errcheck

	val, _, err := key.GetStringValue(runValueKey)
	if err != nil {
		if errors.Is(err, registry.ErrNotExist) {
			return "", nil
		}
		return "", err
	}

	trimmed := strings.TrimSpace(val)
	if trimmed == "" {
		return "", nil
	}

	if strings.HasPrefix(trimmed, "\"") {
		trimmed = strings.TrimPrefix(trimmed, "\"")
		if end := strings.Index(trimmed, "\""); end >= 0 {
			trimmed = trimmed[:end]
		}
	}

	fields := strings.Fields(trimmed)
	if len(fields) == 0 {
		return "", nil
	}

	path := fields[0]
	if path == "" {
		return "", nil
	}
	return filepath.Clean(path), nil
}

func killProcessesByExe(target string, logger *slog.Logger) error {
	target = filepath.Clean(target)
	if target == "" {
		return nil
	}

	script := fmt.Sprintf(
		"$ErrorActionPreference='SilentlyContinue';$t='%s';Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -eq $t } | Select-Object -ExpandProperty ProcessId",
		strings.ReplaceAll(target, "'", "''"),
	)
	cmd := exec.Command("powershell", "-NoProfile", "-Command", script)
	output, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("process query failed: %w: %s", err, strings.TrimSpace(string(output)))
	}

	scanner := bufio.NewScanner(bytes.NewReader(output))
	var pids []int
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" {
			continue
		}
		pid, err := strconv.Atoi(line)
		if err == nil {
			pids = append(pids, pid)
		}
	}

	if err := scanner.Err(); err != nil {
		return err
	}

	if len(pids) == 0 {
		return nil
	}

	self := os.Getpid()
	for _, pid := range pids {
		if pid == self {
			continue
		}
		cmd := exec.Command("taskkill", "/PID", strconv.Itoa(pid), "/T", "/F")
		output, err := cmd.CombinedOutput()
		if err != nil {
			return fmt.Errorf("taskkill pid %d failed: %w: %s", pid, err, strings.TrimSpace(string(output)))
		}
		logger.Info("terminated autorun instance", "pid", pid)
	}

	return nil
}
