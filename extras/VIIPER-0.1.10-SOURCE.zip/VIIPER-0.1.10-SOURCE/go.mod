module github.com/Alia5/VIIPER

go 1.26.2

require (
	github.com/alecthomas/kong v1.15.0
	github.com/alecthomas/kong-toml v0.4.0
	github.com/alecthomas/kong-yaml v0.2.1-0.20240409173824-a56dc1466c79
	github.com/pelletier/go-toml v1.9.5
	github.com/stretchr/testify v1.11.1
	golang.org/x/crypto v0.52.0
	golang.org/x/exp v0.0.0-20260410095643-746e56fc9e2f
	golang.org/x/sys v0.45.0
	golang.org/x/term v0.43.0
	gopkg.in/yaml.v3 v3.0.1
)

require (
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/kr/text v0.2.0 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
)
