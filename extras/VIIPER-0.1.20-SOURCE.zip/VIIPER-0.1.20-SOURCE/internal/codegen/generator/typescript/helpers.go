package typescript

import (
	"strings"

	"github.com/Alia5/VIIPER/internal/codegen/common"
)

func goTypeToTS(goType string) string {
	base, _, _ := common.NormalizeGoType(goType)
	switch base {
	case "byte", "uint8", "uint16", "uint32", "uint64", "int8", "int16", "int32", "int64", "int", "float32", "float64":
		return "number"
	case "bool":
		return "boolean"
	case "string":
		return "string"
	case "any", "interface{}":
		return "unknown"
	default:
		return common.ToTypeName(base)
	}
}

func parseGoMapType(typeStr string) (string, bool) {
	if !strings.HasPrefix(typeStr, "map[") {
		return "", false
	}
	closeIdx := strings.Index(typeStr, "]")
	if closeIdx < 0 {
		return "", false
	}
	valueType := typeStr[closeIdx+1:]
	if valueType == "" {
		return "", false
	}
	return valueType, true
}

func writeFileHeaderTS() string { return common.FileHeader("//", "TypeScript") }
